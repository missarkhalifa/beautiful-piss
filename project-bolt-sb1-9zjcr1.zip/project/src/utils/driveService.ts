import { google } from 'googleapis';

const SCOPES = ['https://www.googleapis.com/auth/drive.file'];

export class DriveService {
  private static auth = new google.auth.GoogleAuth({
    scopes: SCOPES,
    // You'll need to provide your credentials here
    // credentials: require('./credentials.json'),
  });

  private static drive = google.drive({ version: 'v3', auth: this.auth });

  static async uploadVideo(file: File, location: string): Promise<string> {
    try {
      const fileMetadata = {
        name: `${new Date().toISOString()}_${location}_${file.name}`,
        parents: ['YOUR_FOLDER_ID'], // Replace with your Drive folder ID
      };

      const media = {
        mimeType: file.type,
        body: file,
      };

      const response = await this.drive.files.create({
        requestBody: fileMetadata,
        media: media,
        fields: 'id',
      });

      // Set file permissions to private (only accessible by you)
      await this.drive.permissions.create({
        fileId: response.data.id!,
        requestBody: {
          role: 'owner',
          type: 'user',
          emailAddress: 'YOUR_EMAIL', // Replace with your email
        },
      });

      return response.data.id!;
    } catch (error) {
      console.error('Error uploading to Drive:', error);
      throw new Error('Failed to upload video');
    }
  }
}