export const DRIVE_CONFIG = {
  clientId: "1051441750231-cjafd2gmos594ln921acif576r9b0npm.apps.googleusercontent.com",
  clientSecret: "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",
  folderId: "1w-dQVaUvA4sMIRbiVi6Bcwl4S5Cffak_",
  ownerEmail: "missarnoads@gmail.com"
};