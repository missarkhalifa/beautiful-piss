import React, { useCallback, useState } from 'react';
import { useDropzone } from 'react-dropzone';
import { Upload, CheckCircle2, AlertCircle } from 'lucide-react';
import { uploadVideo } from '../services/uploadService';

interface FormData {
  title: string;
}

export default function UploadForm() {
  const [file, setFile] = useState<File | null>(null);
  const [formData, setFormData] = useState<FormData>({ title: '' });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitStatus, setSubmitStatus] = useState<'success' | 'error' | null>(null);
  const [errorMessage, setErrorMessage] = useState<string>('');
  const [uploadProgress, setUploadProgress] = useState(0);

  const onDrop = useCallback((acceptedFiles: File[]) => {
    if (acceptedFiles[0]) {
      setFile(acceptedFiles[0]);
      setSubmitStatus(null);
      setErrorMessage('');
      setUploadProgress(0);
    }
  }, []);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'video/*': ['.mp4', '.mov', '.avi']
    },
    maxSize: 100 * 1024 * 1024, // 100MB max
    multiple: false
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!file) return;

    setIsSubmitting(true);
    setErrorMessage('');
    setUploadProgress(0);

    try {
      const result = await uploadVideo(file, formData.title, (progress) => {
        setUploadProgress(progress);
      });
      
      if (result.success) {
        setSubmitStatus('success');
        setFile(null);
        setFormData({ title: '' });
      } else {
        setSubmitStatus('error');
        setErrorMessage(result.message);
      }
    } catch (error) {
      setSubmitStatus('error');
      setErrorMessage('Upload failed. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6 w-full max-w-xl">
      <div
        {...getRootProps()}
        className={`border-2 border-dashed rounded-lg p-12 text-center cursor-pointer transition-colors
          ${isDragActive ? 'border-accent-400 bg-gray-800/50' : 'border-gray-700 hover:border-accent-400'}
          ${file ? 'bg-gray-800/50 border-accent-400' : ''}`}
      >
        <input {...getInputProps()} />
        <Upload className="mx-auto h-16 w-16 text-accent-400 mb-4" />
        {file ? (
          <div className="space-y-2">
            <p className="text-accent-400 font-medium">Ready to upload: {file.name}</p>
            <p className="text-sm text-gray-300">
              Size: {(file.size / (1024 * 1024)).toFixed(2)} MB
            </p>
            <p className="text-sm text-gray-300">Click or drag to change video</p>
          </div>
        ) : (
          <div className="space-y-2">
            <p className="text-xl font-medium text-gray-100">
              Drop your video here
            </p>
            <p className="text-sm text-gray-300">
              Supports MP4, MOV, or AVI (max 100MB)
            </p>
          </div>
        )}
      </div>

      <div className="space-y-4">
        <div className="relative">
          <label htmlFor="title" className="block text-sm font-medium text-gray-100 mb-1">
            Video Title
          </label>
          <input
            type="text"
            id="title"
            name="title"
            required
            value={formData.title}
            onChange={(e) => setFormData({ title: e.target.value })}
            placeholder="Enter video title"
            className="block w-full rounded-md border-gray-700 bg-gray-800/75 text-white shadow-sm 
                     focus:border-accent-500 focus:ring-accent-500 placeholder-gray-500 p-2"
          />
        </div>
      </div>

      {isSubmitting && (
        <div className="w-full bg-gray-800/50 rounded-full h-4 overflow-hidden">
          <div 
            className="bg-accent-500 h-full transition-all duration-300"
            style={{ width: `${uploadProgress}%` }}
          />
          <p className="text-sm text-gray-300 mt-2 text-center">
            Uploading: {uploadProgress.toFixed(0)}%
          </p>
        </div>
      )}

      {submitStatus && (
        <div className={`rounded-md p-4 ${
          submitStatus === 'success' ? 'bg-accent-900/50' : 'bg-red-900/50'
        }`}>
          {submitStatus === 'success' ? (
            <div className="flex items-center">
              <CheckCircle2 className="h-5 w-5 text-accent-400 mr-2" />
              <p className="text-accent-300">Video uploaded successfully!</p>
            </div>
          ) : (
            <div className="flex items-center">
              <AlertCircle className="h-5 w-5 text-red-400 mr-2" />
              <p className="text-red-300">{errorMessage}</p>
            </div>
          )}
        </div>
      )}

      <button
        type="submit"
        disabled={!file || isSubmitting}
        className={`w-full flex justify-center py-4 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white
          ${!file || isSubmitting
            ? 'bg-gray-700 cursor-not-allowed'
            : 'bg-accent-600 hover:bg-accent-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-accent-500 focus:ring-offset-gray-900'
          }`}
      >
        {isSubmitting ? (
          <span className="flex items-center">
            <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
            </svg>
            Uploading...
          </span>
        ) : (
          'Upload Video'
        )}
      </button>
    </form>
  );
}