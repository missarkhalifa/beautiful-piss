import { UploadProgressCallback } from '../types';

// Using unsigned upload for simplicity and browser-only implementation
const CLOUDINARY_UPLOAD_PRESET = 'PissVideos';  // Change this to your unsigned upload preset
const CLOUDINARY_CLOUD_NAME = 'dsxq60vbw'; // Change this to your cloud name
const UPLOAD_URL = `https://api.cloudinary.com/v1_1/${CLOUDINARY_CLOUD_NAME}/video/upload`;

export interface UploadResponse {
  success: boolean;
  message: string;
  fileUrl?: string;
}

export async function uploadVideo(
  file: File,
  title: string,
  onProgress?: UploadProgressCallback
): Promise<UploadResponse> {
  if (file.size > 100 * 1024 * 1024) {
    return {
      success: false,
      message: 'File size must be less than 100MB'
    };
  }

  const formData = new FormData();
  formData.append('file', file);
  formData.append('upload_preset', CLOUDINARY_UPLOAD_PRESET);
  formData.append('folder', 'beautifulpiss');
  formData.append('public_id', `${Date.now()}-${title.replace(/\s+/g, '-').toLowerCase()}`);
  formData.append('resource_type', 'video');

  try {
    const xhr = new XMLHttpRequest();
    
    const uploadPromise = new Promise<UploadResponse>((resolve, reject) => {
      xhr.open('POST', UPLOAD_URL, true);

      xhr.upload.onprogress = (e) => {
        if (e.lengthComputable) {
          const percentComplete = Math.round((e.loaded / e.total) * 100);
          onProgress?.(percentComplete);
        }
      };

      xhr.onload = () => {
        if (xhr.status === 200) {
          const response = JSON.parse(xhr.responseText);
          resolve({
            success: true,
            message: 'Upload successful!',
            fileUrl: response.secure_url
          });
        } else {
          reject(new Error('Upload failed'));
        }
      };

      xhr.onerror = () => {
        reject(new Error('Upload failed'));
      };

      xhr.send(formData);
    });

    return await uploadPromise;
  } catch (error) {
    console.error('Upload error:', error);
    return {
      success: false,
      message: 'Upload failed. Please try again later.'
    };
  }
}