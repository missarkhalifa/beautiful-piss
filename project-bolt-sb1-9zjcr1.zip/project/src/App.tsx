import React from 'react';
import { Video } from 'lucide-react';
import UploadForm from './components/UploadForm';

export default function App() {
  return (
    <div className="min-h-screen bg-gray-900">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center mb-12">
          <div className="flex items-center justify-center gap-3 mb-4">
            <Video className="h-12 w-12 text-accent-400" />
          </div>
          <h1 className="text-5xl font-bold text-white mb-4">
            BeautifulPiss
          </h1>
          <p className="text-lg text-gray-400 max-w-2xl mx-auto">
            Upload your video securely
          </p>
        </div>

        <div className="flex justify-center">
          <UploadForm />
        </div>

        <footer className="mt-16 text-center space-y-4">
          <p className="text-sm text-gray-500">Your videos are encrypted and stored securely</p>
          <p className="text-xs text-gray-600">
            By uploading videos, you grant BeautifulPiss full rights to use, modify, and share the content on TikTok and other platforms. All rights to uploaded content are transferred to BeautifulPiss upon submission.
          </p>
        </footer>
      </div>
    </div>
  );
}